// MDVLCraft first-join clean-up

PlayerEvents.loggedIn(event => {
  const player = event.player
  // Villager Recruits hands out its manual on first login; take it away once that has happened.
  event.server.scheduleInTicks(20, () => {
    const inventory = player.inventory
    for (let slot = 0; slot < inventory.getContainerSize(); slot++) {
      const stack = inventory.getItem(slot)
      if (stack.id == 'minecraft:written_book' && stack.nbt && stack.nbt.getBoolean('VRManual')) {
        inventory.setItem(slot, Item.empty)
      }
    }
  })
})
